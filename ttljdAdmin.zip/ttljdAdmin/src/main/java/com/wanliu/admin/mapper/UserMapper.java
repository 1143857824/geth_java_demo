package com.wanliu.admin.mapper;

import com.wanliu.admin.pojo.User;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author 梁涛
 * 对应数据库表Player的dao接口
 */
public interface UserMapper extends Mapper<User> {

}
