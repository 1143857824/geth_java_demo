package com.wanliu.admin.mapper;

import com.wanliu.admin.pojo.Bill;
import tk.mybatis.mapper.common.Mapper;

public interface BillMapper extends Mapper<Bill> {
}
